## Day 1 — 2026-05-06

**Hours worked:** 3

**What I did:**
Created GitHub repo,initialized React app, 
installed Tailwind CSS, created Supabase project, 
set up folder structure, and created
all required markdown files. Chose React + plain JS
over Next.js/TS because I chose React with plain 
JavaScript instead of TypeScript because I am more 
confident in JavaScript and wanted to avoid slowing 
down development due to unfamiliar tooling. Given the
7-day constraint, I prioritized delivering a complete,
working product over learning new technologies mid-assignment.

**What I learned:**
Explored supabase more deeply (database+api).

**Blockers / what I'm stuck on:**
...Till now there is no problem.

**Plan for tomorrow:**
Build the spend input form with all 8 required AI tools.
Add localStorage persistence for form state.

## Day 2 — 2026-05-07

**Hours worked:** 4

**What I did:**
Built the Home page and Navbar component with full responsiveness.
Navbar has absolute positioning with backdrop blur, logo, nav links
. Home page renders the Hero section (headline, animated badge, stats strip). Tested on mobile viewport . All CSS variables
(--green, --font-display, --r-md etc.) are centrally defined in
index.css so every component stays visually consistent. Committed
after each major working milestone.

**What I learned:**
Learned how CSS custom properties (variables) work as a design
token system — defining --green once in :root and using it
everywhere means I can retheme the whole app by changing one line.

**Blockers / what I'm stuck on:**
stuck on theme variable in tailwind v4 set up, but now it's working.

**Plan for tomorrow:**
Creating the F Build SpendForm.jsx and ToolRow.jsx — all 8 tool rows with
toggle on/off, plan selector, seats input, and monthly spend input.
Wire up localStorage persistence so form state survives page reload.

## Day 3 — 2026-05-08

**Hours worked:** 3

**What I did:**
Built the Audit page for check the spend add routing for Hero and Audit page using browser-router-dom . Audit page renders all Toolcard where is the all prices,team size,plan etc.

** What I learned **
I learned more about folder structure.How should i make it in real developement.

**Blockers / what I'm stuck on:**
stuck on toggling between two ai model.

**Plan for tomorrow:**
make the Toolcard fully optimize and working . 
Make the result section for see the spend and 
details how can any one make it minimize

## Day 4 — 2026-05-09

**Hours worked:** 3

**What I did:**
Built the Audit page add daisyui for toogle button

** What I learned **
more learn about daisyui plugin how to install and use it for better and simple ui usage.

**Blockers / what I'm stuck on:**
some installation problem occurs when i try to install and use this plugin and I have some issue to collects the data about the ai model pricing , categorize details.

**Plan for tomorrow:**
Make the full Audit page ui working and make it responsive.


## Day 5 — 2026-05-10

**Hours worked:** 3

**What I did:**
Built the Audit result page where we check the result for the search 

** What I learned **
more about css grid item and how can i display the dynamic result data in the page

**Blockers / what I'm stuck on:**
No problem occurs in todays work.

**Plan for tomorrow:**
add supabase and save the result data on it. make the share option that's how user can share there audit result
